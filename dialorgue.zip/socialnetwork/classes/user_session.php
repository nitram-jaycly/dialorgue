<?php
	if (Login::isLoggedIn()) 
	{
			$userid = Login::isLoggedIn();
	} else 	{
				die(header("location: login.php"));
			}
	
	$userid = Login::isLoggedIn();
	$user_name = DB::query('SELECT username FROM users WHERE id=:id', array(':id'=>$userid))[0]['username'];
?>