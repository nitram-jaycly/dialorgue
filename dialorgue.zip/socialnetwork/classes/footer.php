	<div class="footer">
        <footer>
            <div class="container">
                <center><p class="copyright">Dialorgue © <script>document.write(new Date().getFullYear());</script></p></center>
            </div>
        </footer>
    </div>