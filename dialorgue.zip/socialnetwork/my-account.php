<?php
//$page = 'User';

include('./classes/DB.php');
include('./classes/Login.php');
include('./classes/user_session.php');


if (isset($_POST['uploadprofileimg'])) {

        Image::uploadImage('profileimg', "UPDATE users SET profileimg = :profileimg WHERE id=:userid", array(':userid'=>$userid));

}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Network</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>

<body>

	<?php include('./classes/header.php'); ?>
	
	<div class="container">
        <h1>My Account</h1>
	</div>
	<br>
    <div>
        <div class="container">
			<div class="login-clean">
				<form action="my-account.php" method="post" enctype="multipart/form-data">
					<div class="form-group">	
						Upload a profile image:
					</div>
					<div class="form-group">
						<input type="file" name="profileimg">
					</div>
					<div class="form-group">
						<button class="btn btn-primary btn-block" type="submit" id="login" name="uploadprofileimg" type="button" value="Upload Image" >Upload Image</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<br><br>
	<?php include('./classes/footer.php'); ?>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
</body>

</html>